/**
 * 
 */
/**
 * 
 */
module module1FX {
    requires javafx.controls;
    exports module1FX;
}
